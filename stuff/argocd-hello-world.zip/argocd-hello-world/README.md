# ArgoCD Hello World Application

This project demonstrates how to deploy a simple Hello World application using ArgoCD and Kustomize. The application is configured to respond to three different hostnames: `h1.hs.local`, `h2.hs.local`, and `h3.hs.local`. 

## Project Structure

The project is organized into two main directories:

- **base**: Contains the base Kubernetes resources.
  - `deployment.yaml`: Defines the Kubernetes Deployment for the Hello World image.
  - `ingress.yaml`: Defines the standard Ingress resource for routing traffic.
  - `kustomization.yaml`: Kustomize configuration for the base resources.

- **overlays**: Contains overlays for each hostname.
  - **h1**: Customization for the `h1.hs.local` hostname.
    - `kustomization.yaml`: Kustomize configuration for the h1 overlay.
    - `ingress-patch.yaml`: Patch for the Ingress resource to include `h1.hs.local`.
  - **h2**: Customization for the `h2.hs.local` hostname.
    - `kustomization.yaml`: Kustomize configuration for the h2 overlay.
    - `ingress-patch.yaml`: Patch for the Ingress resource to include `h2.hs.local`.
  - **h3**: Customization for the `h3.hs.local` hostname.
    - `kustomization.yaml`: Kustomize configuration for the h3 overlay.
    - `ingress-patch.yaml`: Patch for the Ingress resource to include `h3.hs.local`.

## Deployment Instructions

1. **Install ArgoCD**: Follow the official ArgoCD installation guide to set up ArgoCD in your Kubernetes cluster.

2. **Deploy the Application**:
   - Navigate to the desired overlay directory (e.g., `overlays/h1`, `overlays/h2`, or `overlays/h3`).
   - Use the following command to apply the Kustomize configuration:
     ```
     kubectl apply -k .
     ```

3. **Access the Application**: After deployment, you can access the Hello World application using the respective hostname in your browser.

## Notes

- Ensure that your local DNS or `/etc/hosts` file is configured to resolve `h1.hs.local`, `h2.hs.local`, and `h3.hs.local` to the IP address of your Kubernetes cluster.
- Modify the `deployment.yaml` file in the base directory to change the container image or other deployment settings as needed.